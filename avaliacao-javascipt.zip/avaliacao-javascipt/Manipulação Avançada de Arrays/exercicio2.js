const array = [10, 20, 30, 40, 50]

const array2 = array.filter(function(number)
{ 
    return number > 25;
});

console.log(array2)