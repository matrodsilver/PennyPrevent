const array = [25, 42, 13, 24, 51]

const array2 = array.map(function(element){ 
        return element *2;
});

console.log(array2)