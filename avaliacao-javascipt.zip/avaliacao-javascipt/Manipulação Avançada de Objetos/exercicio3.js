var array1 = ["boi", "teclado", "roraima", "shitzu"]
var array2 = ["bahia", "Dani Carvajal", "canavial de beringela", "xampson"]

var array3 = [...array1, ...array2]

console.log(array3)