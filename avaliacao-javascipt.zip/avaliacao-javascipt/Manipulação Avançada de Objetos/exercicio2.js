var produto = {nome: "farofa yoki tradicional 400g", preço: 8.79, quantidade: 400000}

var {nome,preço} = produto

console.log(nome, " | ",preço)