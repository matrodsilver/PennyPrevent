var pessoa = {"nome":1, "idade":2}
pessoa["nome"] = "Robson"
pessoa["idade"] = 87
pessoa["profissão"] = "catador de coco"

console.log(pessoa)