- Streamlit recarrega página quando recebe input, então "While True" causa erro na leitura do stremlit

- A maioria (se não todas) as coisas que dizem "print" são strings que são mostradas no strealmit, não printadas no terminal

- Erros dizendo que a variável ´input´ não deve ser string podem ser ignorados, porque condicionais previnem isso → se uma variável se chama ´input´, python pode reconhecer como a função builtin e gerar pseudo-erros (por isso o nome foi mudado pra inputDados)