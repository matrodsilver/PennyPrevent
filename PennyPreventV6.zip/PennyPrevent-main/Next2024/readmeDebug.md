# Notas

- Tentar colocar Predição em tempo real em outra tab                      !

- Colocar try: except: para ver se arquivo existe na página de downloads  !

- Colocar predições no firebase                                           !

- No momento, chatbot só é ativo após o teste manual

- Streamlit entra em conflito tentando rodar pushbullet (separar scripts)
